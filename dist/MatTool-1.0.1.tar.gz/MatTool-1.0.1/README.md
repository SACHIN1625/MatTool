# MatTool 1.0.1


## How to install

```
pip install MatTool
```
## If you are trouble installing, try this
```
pip3 install MatTool
```
## How to use

Some example codes:

```
from MatTool import MatTool
MatTool.MatDet(a)	# a is multi dimensional list(i.e matrix), it returns determinant of a matrix.

from MatTool import MatTool
MatTool.MatInverse(a)	# a is multi dimensional list(i.e matrix), it returns inverse of a matrix.

from MatTool import MatTool
MatTool.MatTranspose(a)	# a is multi dimensional list(i.e matrix), it returns transpose of a matrix.

from MatTool import MatTool
MatTool.MatProduct(a,b)	# a,b are multi dimensional lists(i.e matrices), it returns product of a and b matrix.


```
If you find any error! Feel free to contact me through mail!

